"""Local operator CLI. Authentication/API/UI are deferred; synthetic data only."""

import argparse
import json
import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from revenueos.analytics import metrics
from revenueos.contracts import Manifest
from revenueos.db import get_engine
from revenueos.ingestion import BundleError, commit_bundle, preview_bundle
from revenueos.synthetic import generate


def _run() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    synth = sub.add_parser("synthetic")
    synth.add_argument("path", type=Path)
    synth.add_argument("--seed", type=int, default=42)
    synth.add_argument("--leads", type=int, default=1000)
    synth.add_argument("--golden", action="store_true")
    for action in ("init-org", "preview", "commit"):
        command = sub.add_parser(action)
        command.add_argument("path", type=Path)
        if action == "commit":
            command.add_argument("--confirm", required=True, help="Exact preview_hash from preview")
    report = sub.add_parser("analytics")
    report.add_argument("--organization", required=True, type=UUID)
    report.add_argument("--dataset", required=True, type=UUID)
    report.add_argument("--start", required=True, type=datetime.fromisoformat)
    report.add_argument("--end", required=True, type=datetime.fromisoformat)
    args = parser.parse_args()
    if args.command == "synthetic":
        generate(args.path, seed=args.seed, leads=args.leads, golden=args.golden)
        print("Generated SYNTHETIC CSV bundle")
        return
    engine = get_engine()
    try:
        if args.command in ("init-org", "preview", "commit"):
            metadata = Manifest.model_validate_json((args.path / "manifest.json").read_bytes())
            if metadata.data_mode != "synthetic":
                raise ValueError("CLI is synthetic-only pending real-data security readiness")
        if args.command == "init-org":
            with engine.begin() as connection:
                connection.execute(
                    text(
                        "INSERT INTO organizations"
                        "(id,name,data_mode,reporting_timezone,default_currency)"
                        " VALUES (:id,:name,:mode,:zone,:currency) ON CONFLICT (id) DO NOTHING"
                    ),
                    {
                        "id": metadata.organization_id,
                        "name": metadata.organization_name,
                        "mode": metadata.data_mode,
                        "zone": metadata.reporting_timezone,
                        "currency": metadata.default_currency,
                    },
                )
            print("Synthetic organization initialized (or already exists)")
        elif args.command == "preview":
            with engine.connect() as connection:
                print(json.dumps(preview_bundle(args.path, connection).summary(), indent=2))
        elif args.command == "commit":
            print(
                json.dumps(
                    asdict(commit_bundle(args.path, engine, args.confirm)), default=str, indent=2
                )
            )
        else:
            with engine.connect() as connection:
                print(
                    json.dumps(
                        metrics(connection, args.organization, args.dataset, args.start, args.end),
                        default=str,
                        indent=2,
                    )
                )
    finally:
        engine.dispose()


def main() -> None:
    try:
        _run()
    except BundleError as exc:
        # BundleError contains controlled codes only, never raw row/manifest values.
        print(f"Import rejected: {exc}", file=sys.stderr)
        raise SystemExit(2) from None
    except (ValueError, OSError, KeyError):
        print("Invalid input/configuration; check paths, manifest, and interval.", file=sys.stderr)
        raise SystemExit(2) from None
    except SQLAlchemyError:
        print("Database operation failed; verify configuration and migrations.", file=sys.stderr)
        raise SystemExit(3) from None


if __name__ == "__main__":
    main()
