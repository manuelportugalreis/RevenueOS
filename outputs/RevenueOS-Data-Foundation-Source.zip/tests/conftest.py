"""Only an explicitly disposable local PostgreSQL database may be reset."""

import os
from collections.abc import Iterator
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import Engine, text
from sqlalchemy.engine import make_url

from revenueos.db import get_engine
from revenueos.synthetic import SYNTHETIC_ORG, generate

ROOT = Path(__file__).resolve().parents[1]


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption("--require-db", action="store_true", help="Fail instead of skipping DB tests")


@pytest.fixture(scope="session")
def db_engine(request: pytest.FixtureRequest) -> Iterator[Engine]:
    url = os.environ.get("TEST_DATABASE_URL")
    if not url:
        if request.config.getoption("--require-db"):
            pytest.fail("TEST_DATABASE_URL is required")
        pytest.skip("TEST_DATABASE_URL absent; database integration NOT verified")
    target = make_url(url)
    if (
        target.host not in ("127.0.0.1", "localhost")
        or target.database != "revenueos_test"
        or os.environ.get("REVENUEOS_TEST_ALLOW_RESET") != "1"
    ):
        pytest.fail("Refusing reset: local revenueos_test DB and explicit reset consent required")
    os.environ["DATABASE_URL"] = url
    command.upgrade(Config(str(ROOT / "alembic.ini")), "head")
    engine = get_engine(url)
    yield engine
    engine.dispose()


@pytest.fixture
def engine(db_engine: Engine) -> Engine:
    # All names are fixed application tables. No schema/database DROP or unrelated data reset.
    tables = (
        "suppression_tombstones,lead_outcomes,opportunity_stage_events,opportunity_leads,"
        "interactions,lead_private,opportunities,leads,accounts,import_errors,datasets,"
        "import_batches,organizations"
    )
    with db_engine.begin() as connection:
        connection.execute(text(f"TRUNCATE {tables} RESTART IDENTITY"))
        connection.execute(
            text(
                "INSERT INTO organizations(id,name,data_mode,default_currency) "
                "VALUES (:org,'SYNTHETIC Test','synthetic','USD')"
            ),
            {"org": SYNTHETIC_ORG},
        )
    return db_engine


@pytest.fixture
def bundle(tmp_path: Path) -> Path:
    path = tmp_path / "bundle"
    generate(path, golden=True)
    return path
