import os

from sqlalchemy import Engine, create_engine


def get_engine(url: str | None = None) -> Engine:
    target = url or os.environ["DATABASE_URL"]
    if not target.startswith("postgresql+psycopg://"):
        raise ValueError("RevenueOS requires PostgreSQL through psycopg")
    return create_engine(
        target,
        pool_pre_ping=True,
        pool_timeout=5,
        hide_parameters=True,
        connect_args={"options": "-c timezone=UTC", "connect_timeout": 5},
    )
