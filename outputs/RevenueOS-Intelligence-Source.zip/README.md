# RevenueOS: CRM data and offline intelligence

RevenueOS is a production-minded revenue-intelligence portfolio project. It implements PostgreSQL schema/migrations, synthetic CRM fixtures, confirmed CSV ingestion, SQL analytics, explainable lead priority, cited document retrieval, structured recommendation/provider contracts, and offline evaluation/cost tracking.

See [the intelligence guide](docs/13-intelligence-guide.md) and [its acceptance criteria](docs/12-intelligence-acceptance.md). No live model has been evaluated, predictive training remains gated off, and recommendation quality gates are not all met. No web UI, CRM API, or message delivery is implemented.

[Intelligence verification](docs/14-intelligence-verification.md): 109 tests passed on PostgreSQL 18.6. The frozen synthetic retrieval comparison met its target; recommendation false abstention did not. Test success and release-quality gates are reported separately.

Start with [setup and design decisions](docs/10-data-foundation-guide.md), [acceptance criteria](docs/09-data-foundation-acceptance.md), and [the planning pack](docs/README.md).

[Verification report](docs/11-data-foundation-verification.md): 52 tests passed on PostgreSQL 18.6. Docker execution, hosted CI, and production readiness remain unverified.

## Quick start

Python 3.12+ and PostgreSQL 18 are required. Docker Compose is an optional database convenience. Commands below use the Windows virtualenv paths; on Linux/macOS use `.venv/bin/python`.

```powershell
python -m venv .venv
./.venv/Scripts/python -m pip install -r requirements.lock
./.venv/Scripts/python -m pip install --no-build-isolation --no-deps -e .
# Copy .env.example to .env and set a local password before starting Compose.
docker compose up -d db
# Set DATABASE_URL explicitly in your shell; Python does not auto-load .env.
$env:DATABASE_URL='postgresql+psycopg://revenueos:YOUR_PASSWORD@127.0.0.1:5432/revenueos'
./.venv/Scripts/python -m alembic upgrade head
./.venv/Scripts/python -m revenueos.cli init-org data/synthetic/golden
./.venv/Scripts/python -m revenueos.cli preview data/synthetic/golden
./.venv/Scripts/python -m revenueos.cli commit data/synthetic/golden --confirm PREVIEW_HASH
./.venv/Scripts/python -m revenueos.cli analytics --organization 11111111-1111-4111-8111-111111111111 --dataset DATASET_UUID --start 2026-08-01T00:00:00Z --end 2026-10-01T00:00:00Z
```

Percent-encode special characters in database URL passwords. The CLI is a local operator tool restricted to synthetic bundles; it is not an authenticated service. No demo should contain real business data yet.

## Verify

Create a separate empty local database named `revenueos_test`; never use a production database. Tests reset only the fixed RevenueOS tables but migration tests deliberately drop/recreate them in that disposable database.

```powershell
$env:TEST_DATABASE_URL='postgresql+psycopg://revenueos:YOUR_PASSWORD@127.0.0.1:5432/revenueos_test'
$env:REVENUEOS_TEST_ALLOW_RESET='1'
./.venv/Scripts/python -m pytest --require-db
./.venv/Scripts/python -m ruff check src migrations tests
./.venv/Scripts/python -m ruff format --check src migrations tests
./.venv/Scripts/python -m mypy src
```

Without `TEST_DATABASE_URL`, database tests explicitly skip; use `--require-db` to prevent treating that as a verified database build. CI uses actual PostgreSQL, not SQLite. CI and Compose configuration are supplied; their remote/container execution status is reported separately from local verification.
