# RevenueOS planning pack

Status: proposed architecture; awaiting owner approval. Date: 2026-10-16.

RevenueOS helps B2B SaaS teams decide which inbound leads to work, understand the evidence, and prepare outreach for human review. The first product slice is **validated CSV → trusted metrics → explained priority → cited recommendation → reviewed draft**.

No application, migrations, model integrations, infrastructure, or feature tests have been implemented. This pack defines the work to approve first.

## Reading order and deliverables

| Document | Contents | Requested deliverables |
|---|---|---|
| [Product requirements](01-product-requirements.md) | Problem, personas, scope, stories, metric definitions | A, B, C |
| [Architecture and decisions](02-architecture.md) | Components, flows, interfaces, alternatives, deployment | D; technical decisions |
| [Data model](03-data-model.md) | Tables, relationships, constraints, history, ingestion | E |
| [AI design](04-ai-design.md) | Rules, ML, retrieval, structured generation, bounded tools | F |
| [Security and governance](05-security-governance.md) | Access, privacy, approvals, threats, operational controls | G |
| [Evaluation](06-evaluation.md) | Baselines, datasets, gates, measurement protocols | H |
| [Roadmap and risks](07-roadmap-risks.md) | Phases, acceptance, dependencies, risk register | I, J |
| [Pilot and business impact](08-pilot-roi.md) | Recruitment, experiments, costs, ROI evidence | K |

## Repository inspection

The supplied working directory was inspected, including hidden-file discovery and applicable ancestor `AGENTS.md` checks. Initially only empty `work/` and `outputs/` directories existed. No source, documentation, configuration, datasets, or applicable `AGENTS.md` files were found. `git rev-parse` and `git status` reported that this directory is not a Git repository. There is no existing application to preserve or Git diff to report. Inspection scope is this workspace and its instruction ancestors, not unrelated user directories.

## Decision status and assumptions

| Item | Status | Design implication |
|---|---|---|
| B2B SaaS inbound sales | Confirmed by owner | Prioritize first-response and qualification workflows |
| Small team, 5–20 commercial users | Assumption | Single-business pilot; modest concurrency |
| CSV first, pilot data access unknown | Assumption pending answer | Synthetic-only demonstration until data approval |
| Approximately 10,000 leads, 100,000 interactions, 200 approved documents | Planning workload assumption | Load-test envelope; not customer evidence |
| English, one reporting timezone, one currency per pilot | Assumption | Preserve UTC source times; no currency aggregation without conversion policy |
| Provider-neutral, hosted model allowed for synthetic data | Proposal | Real data requires separate provider/privacy review |
| $100/month demo operations ceiling | Provisional budget target | Includes hosting/model usage; excludes engineering labor; no price estimate asserted |
| 30-day qualification outcome, 90-day revenue follow-up | Proposed business definitions | Owner must align with actual sales cycle before pilot |
| Team-wide access to approved internal sales documents | Assumption | Add finer document scopes before restricted material is admitted |

All numerical quality, latency, cost, and impact targets in this pack are **proposed acceptance criteria**, not measured results. No ROI, model accuracy, runtime benchmark, or user adoption has been measured. Synthetic outcomes demonstrate plumbing and evaluation mechanics only.

## Approval requested

Approve or amend the modular monolith, rules-first prioritization, PostgreSQL search-first RAG, provider adapter, single-business pilot, and draft-only human approval boundary. Pending material inputs are pilot data availability and mandatory hosting/provider/residency/budget constraints. Those can change pilot scope; they do not prevent review of this proposal. Implementation stays blocked until explicit architecture approval.

## Evidence and references

Official technical references were checked on 2026-10-16 and are linked beside relevant decisions. They substantiate component capabilities and design considerations; they do not substantiate RevenueOS performance. Exact supported dependency versions and provider pricing must be selected and locked during implementation.
